package net.phoenix_archives.phoenix_archive.api;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.Event;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Fired once during Phoenix Archive's data reload (server-side), after its own datapack/config lore
 * entries are loaded but before the phoenix_archives is finalized. Other mods listen on
 * MinecraftForge.EVENT_BUS and call register(...) to contribute their own LoreEntry objects into the
 * same phoenix_archives -- unlock tracking, categories, sync, and rendering all Just Work since a registered
 * entry goes through the exact same LoreEntry/LORE_ENTRIES pipeline as every JSON-loaded one.
 *
 * Firing from inside the reload listener (one controlled point, not scattered mod-init calls)
 * sidesteps the class of bug SuiteHudBar.register() hit in phoenix_wiki -- concurrent registration
 * calls racing on shared state during parallel mod setup. There's exactly one thread doing the
 * registering here, at a well-defined point in the reload cycle.
 */
public class ArchiveRegisterEntriesEvent extends Event {

    private final Map<ResourceLocation, LoreEntry> entries = new LinkedHashMap<>();

    public void register(ResourceLocation id, LoreEntry entry) {
        if (id == null || entry == null) return;
        entries.put(id, entry);
    }

    public Map<ResourceLocation, LoreEntry> getRegisteredEntries() {
        return entries;
    }
}
