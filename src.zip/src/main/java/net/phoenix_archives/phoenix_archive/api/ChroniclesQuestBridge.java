package net.phoenix_archives.phoenix_archive.api;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.fml.ModList;
import net.phoenixvine.chronicles.QuestAPI;

/**
 * Optional bridge to Phoenix Chronicles' own quest tree, used by a "chronicles_quest" lore condition
 * (see TriggerRegistry) alongside the existing FTB-Quests-based questId field. Chronicles quest ids
 * are namespaced strings ("modid:quest_path"), not the numeric ids FTB Quests uses, so this is a
 * separate condition rather than a drop-in replacement for questId.
 *
 * Compile-only dependency (see build.gradle) -- isLoaded() must be checked before calling
 * isCompleted(), and every reference to QuestAPI must stay inside this class so the JVM never needs
 * to resolve it when Chronicles isn't installed.
 */
public final class ChroniclesQuestBridge {

    private ChroniclesQuestBridge() {}

    public static boolean isLoaded() {
        return ModList.get().isLoaded("phoenix_chronicles");
    }

    public static boolean isCompleted(ServerPlayer player, String questId) {
        return QuestAPI.isCompleted(player, questId);
    }

    /** Client-safe overload (works with the client's own LocalPlayer) for render-time checks. */
    public static boolean isCompleted(Player player, String questId) {
        return QuestAPI.isCompleted(player, questId);
    }
}
