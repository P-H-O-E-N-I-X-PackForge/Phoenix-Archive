package net.phoenix_archives.phoenix_archive.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.phoenix_archives.phoenix_archive.PhoenixArchive;
import net.phoenix_archives.phoenix_archive.api.LoreDataLoader;
import net.phoenix_archives.phoenix_archive.api.LoreEntry;
import net.phoenix_archives.phoenix_archive.client.render.shader.ArchiveShaderManager;
import net.phoenixvine.chronicles.client.screen.ChronicleOverviewScreen;
import net.phoenixvine.chronicles.model.QuestNode;
import net.phoenixvine.chronicles.registry.QuestTreeRegistry;
import net.phoenixvine.wiki.client.suite.SuiteHudBar;
import net.phoenixvine.wiki.theme.PhoenixTheme;

import static net.phoenix_archives.phoenix_archive.PhoenixArchive.MOD_ID;

@OnlyIn(Dist.CLIENT)
public class ArchiveClient {

    /**
     * Shadertoy-style "corrupted data" effect used behind the torn-page placeholder (see
     * ArchiveScreen.renderTornPage). Written to config/phoenix_archive/shaders/ on first launch if
     * missing so the effect works out of the box; a pack author can freely edit or replace the file
     * afterward since it's a plain user shader from that point on.
     */
    public static final String TORN_PAGE_SHADER_ID = "torn_page";

    private static final String TORN_PAGE_SHADER_SOURCE = """
            // Default "corrupted data" effect for Archive's torn/missing-page placeholder.
            // Edit or replace this file freely -- it's only written once, on first launch.
            vec2 hash2(vec2 p) {
                p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
                return fract(sin(p) * 43758.5453);
            }

            void mainImage(out vec4 fragColor, in vec2 fragCoord) {
                vec2 uv = fragCoord / iResolution.xy;

                vec3 col = vec3(0.02, 0.02, 0.03);

                float bandY = floor(uv.y * 24.0);
                float bandTime = floor(iTime * 6.0 + bandY * 3.7);
                float glitch = step(0.94, fract(sin(bandTime) * 43758.5453));
                float shift = (fract(sin(bandTime * 1.37) * 12345.6) - 0.5) * 0.06 * glitch;
                uv.x += shift;

                float n = hash2(floor(uv * iResolution.xy * 0.5) + iTime * 60.0).x;
                col += vec3(0.05) * n;

                col *= 0.9 + 0.1 * sin(uv.y * iResolution.y * 3.14159);

                float vig = smoothstep(0.9, 0.2, length(uv - 0.5));
                col *= mix(0.4, 1.0, vig);

                float alertFlicker = step(0.985, fract(sin(floor(iTime * 2.0)) * 91.7));
                col = mix(col, vec3(0.6, 0.08, 0.08), alertFlicker * 0.15);

                fragColor = vec4(col, 1.0);
            }
            """;

    public static void onClientSetup(final FMLClientSetupEvent event) {
        Minecraft mc = Minecraft.getInstance();
        PhoenixArchive.LOGGER.info("PHOENIX_OS // Client setup, registering HUD bar entry...");

        ArchivePalette.refresh(PhoenixTheme.current());
        PhoenixTheme.addChangeListener(() -> ArchivePalette.refresh(PhoenixTheme.current()));

        ArchiveShaderManager.ensureDefault(TORN_PAGE_SHADER_ID, TORN_PAGE_SHADER_SOURCE);

        registerHudBar(mc);
    }

    /**
     * Deep-link entry point for other mods: opens the Archive on the lore entry whose
     * "chronicles_quest" condition matches {@code chroniclesQuestId}, if one exists. Returns whether
     * a matching entry was found and opened -- the caller (e.g. Chronicles' quest-node context menu)
     * decides what to do if none exists (usually: don't show the menu item at all).
     */
    public static boolean openLoreForChroniclesQuest(Screen returnTo, String chroniclesQuestId) {
        for (LoreEntry entry : LoreDataLoader.LORE_ENTRIES.values()) {
            if (chroniclesQuestId.equals(entry.getConditions().get("chronicles_quest"))) {
                Minecraft.getInstance().setScreen(new ArchiveScreen(returnTo, entry));
                return true;
            }
        }
        return false;
    }

    /** Cheap existence check, for deciding whether to show a "View Lore" menu item at all. */
    public static boolean hasLoreForChroniclesQuest(String chroniclesQuestId) {
        for (LoreEntry entry : LoreDataLoader.LORE_ENTRIES.values()) {
            if (chroniclesQuestId.equals(entry.getConditions().get("chronicles_quest"))) return true;
        }
        return false;
    }

    /**
     * The other half of the deep link: opens Chronicles' quest tree centered on the given quest id
     * (a lore entry's own "chronicles_quest" condition value). No-ops if Chronicles isn't loaded or
     * the id doesn't resolve to a real quest -- every reference to Chronicles' classes stays inside
     * this one guarded method so the JVM never needs to resolve them when Chronicles is absent.
     */
    public static void openChroniclesQuest(Screen returnTo, String chroniclesQuestId) {
        if (!ModList.get().isLoaded("phoenix_chronicles")) return;
        ResourceLocation id = ResourceLocation.tryParse(chroniclesQuestId);
        if (id == null) return;
        QuestNode node = QuestTreeRegistry.getQuest(id);
        if (node == null) return;

        ChronicleOverviewScreen screen = new ChronicleOverviewScreen(returnTo);
        Minecraft.getInstance().setScreen(screen);
        screen.navigateToNode(node);
    }

    private static void registerHudBar(Minecraft mc) {
        ResourceLocation iconPath = ResourceLocation.fromNamespaceAndPath(
                MOD_ID,
                "textures/item/lore_terminal.png");

        SuiteHudBar.register(
                MOD_ID,
                SuiteHudBar.PRIORITY_ARCHIVE,
                iconPath,
                () -> Component.literal("§fOpen Archive"),
                () -> 1,
                () -> mc.setScreen(new ArchiveScreen(mc.screen)),
                16,
                112,
                false);
    }
}
