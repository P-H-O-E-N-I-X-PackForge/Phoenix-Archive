package net.phoenix_archives.phoenix_archive.client.rich;

import net.minecraft.resources.ResourceLocation;

import java.util.List;

public sealed interface RichBlock {

    List<RichSpan> spans();

    record Heading(int level, List<RichSpan> spans) implements RichBlock {}

    record Paragraph(List<RichSpan> spans) implements RichBlock {}

    record ListItem(String marker, int indent, List<RichSpan> spans) implements RichBlock {}

    record Checklist(String checkKey, boolean checkedDefault, int indent, List<RichSpan> spans) implements RichBlock {}

    record Quote(List<RichSpan> spans) implements RichBlock {}

    record CodeBlock(String lang, String code) implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Callout(String type, String title, List<RichBlock> children) implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Details(String expandKey, String title, List<RichBlock> children) implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record CollapsibleSection(int level, List<RichSpan> headingSpans, String collapseKey,
                              List<RichBlock> children)
            implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return headingSpans;
        }
    }

    record ScaleDirective(float multiplier) implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Table(List<List<RichSpan>> header, List<List<List<RichSpan>>> rows) implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Rule() implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Blank() implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    /**
     * A {@code :::if <key>:<value>} ... {@code :::} block ("if dimension:minecraft:the_nether") --
     * Archive-only extension, not part of phoenix_wiki's markdown. Its children render only while the
     * condition is currently true; unlike every other block here this is re-checked every render, not
     * just once at parse time, so an entry using this reads differently as suite-wide state changes
     * ("living" content) and can redact/reveal individual paragraphs instead of the whole entry
     * ("progressive redaction"). See ArchiveScreen.resolveConditionals.
     */
    record ConditionalSection(String conditionKey, String conditionValue, List<RichBlock> children)
            implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    /**
     * A {@code :::hotspots <image>,<w>,<h>} ... {@code :::} block -- Archive-only extension. Lines
     * inside starting with {@code @x,y} place a clickable/hoverable marker at that pixel offset into
     * the image, showing the rest of the line as a tooltip. Opt-in per entry (a plain author has to
     * write this syntax deliberately); nothing renders this way by default.
     */
    record HotspotImage(ResourceLocation image, int width, int height, List<Hotspot> hotspots)
            implements RichBlock {

        @Override
        public List<RichSpan> spans() {
            return List.of();
        }
    }

    record Hotspot(int x, int y, String tooltip) {}
}
